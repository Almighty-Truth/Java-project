/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holidaycelebrations;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Cristy
 */
public class HolidayCelebrations { //this is the driver class

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        ArrayList<Celebratable> myFamilyTraditions = createTraditions();
        celebrateHolidays(myFamilyTraditions);

    }

    public static ArrayList<Celebratable> createTraditions() throws IOException {
        //Create an ArrayList that will hold objects of grandParents, parents, and children
        ArrayList<Celebratable> KingsList = new ArrayList<>();

        File aFile = new File("holidays.txt");
        try (Scanner inFile = new Scanner(aFile)) {

            GrandparentsTradition aGrandParent;
            ParentsTradition aParent;
            ChildrenTradition aChild;

            String typeRecord; //this doesn't get passed in, it represents grandparent, child, parent

            String holidayName;
            String holidaySeason;
            String timeOfDayCelebration;
            String mainDishName;
            int numberOfSideDishes;
            String locationOfGathering;
            double costOfMeal;
            String mealSource;

            int numberInvited;
            String traditionalDessert;
            String traditionalDrink;
            double costPerDessert;
            double costPerDrink;

            String holidayGame;
            String holidayStorybook;
            String holidayMovie;
            double costOfMovie;

            while (inFile.hasNext()) {

                //read the file and create the appropriate object (GrandparentsTradition, ParentsTradition, and ChildrenTradition)
                //Remember to use an if-statement to check the first letter of the record and determine what object to create
                //instantiate the corresponding object:  aGrandParent, aParent, or aChild
                //add the object created to the arrayList
                String line = inFile.nextLine();

                String[] tokens = line.split(" ");
                typeRecord = tokens[0];
                holidayName = tokens[1];
                holidaySeason = tokens[2];
                timeOfDayCelebration = tokens[3];
                mainDishName = tokens[4];
                numberOfSideDishes = Integer.parseInt(tokens[5]);
                locationOfGathering = tokens[6];
                costOfMeal = Double.parseDouble(tokens[7]);
                mealSource = tokens[8];

                if (typeRecord.toLowerCase().equals("g")) {

                    aGrandParent = new GrandparentsTradition(holidayName, holidaySeason,
                            timeOfDayCelebration, mainDishName, numberOfSideDishes,
                            locationOfGathering, costOfMeal, mealSource);
                    KingsList.add(aGrandParent);
                } else if (typeRecord.toLowerCase().equals("p")) {

                    numberInvited = Integer.parseInt(tokens[9]);
                    traditionalDessert = tokens[10];
                    traditionalDrink = tokens[11];
                    costPerDessert = Double.parseDouble(tokens[12]);
                    costPerDrink = Double.parseDouble(tokens[13]);

                    aParent = new ParentsTradition(holidayName, holidaySeason, timeOfDayCelebration,
                            mainDishName, numberOfSideDishes, locationOfGathering, costOfMeal,
                            mealSource, numberInvited, traditionalDessert, traditionalDrink,
                            costPerDessert, costPerDrink);
                    KingsList.add(aParent);
                } else if (typeRecord.toLowerCase().equals("c")) {

                    numberInvited = Integer.parseInt(tokens[9]);
                    traditionalDessert = tokens[10];
                    traditionalDrink = tokens[11];
                    costPerDessert = Double.parseDouble(tokens[12]);
                    costPerDrink = Double.parseDouble(tokens[13]);
                    holidayGame = tokens[14];
                    holidayStorybook = tokens[15];
                    holidayMovie = tokens[16];
                    costOfMovie = Double.parseDouble(tokens[17]);

                    aChild = new ChildrenTradition(holidayName, holidaySeason, timeOfDayCelebration,
                            mainDishName, numberOfSideDishes, locationOfGathering, costOfMeal,
                            mealSource, numberInvited, traditionalDessert, traditionalDrink,
                            costPerDessert, costPerDrink, holidayGame, holidayStorybook,
                            holidayMovie, costOfMovie);
                    KingsList.add(aChild);

                }
            }
        }
       
        return KingsList;

        //return the arrayList created and populated.
    }

    public static void celebrateHolidays(ArrayList<Celebratable> myFamilyTraditions) {
        //code the celebrateHolidays method to iterate through the arrayList of objects
        // calls the "celebrate" and "tabulate" polymorphic methods.
        for (int i = 0; i < myFamilyTraditions.size(); ++i) {
            System.out.println(myFamilyTraditions.get(i).celebrate());
            System.out.println(myFamilyTraditions.get(i).tabulateCost());

        }
    }

}
