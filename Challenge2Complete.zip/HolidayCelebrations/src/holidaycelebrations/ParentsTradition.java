/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holidaycelebrations;

//Code the ParentsTradition  class here:

class ParentsTradition extends GrandparentsTradition {
    private int numberInvited;
    private String traditionalDessert;
    private String traditionalDrink;
    private double costPerDessert;
    private double costPerDrink;
    
    public String honor()
            {
                return "we choose to honor our family traditions";
            }
            

    public ParentsTradition(String holidayName, String holidaySeason, 
            String timeOfDayCelebration, String mainDishName, int numberOfSideDishes, 
            String locationOfGathering, double costOfMeal, String mealSource, 
            int numberInvited, String traditionalDessert, String traditionalDrink, 
            double costPerDessert, double costPerDrink) {
        super(holidayName, holidaySeason, timeOfDayCelebration, mainDishName,
                numberOfSideDishes, locationOfGathering, costOfMeal,
                mealSource);
       this.numberInvited = numberInvited;
        this.traditionalDessert = traditionalDessert;
        this.traditionalDrink = traditionalDrink;
        this.costPerDessert = costPerDessert;
        this.costPerDrink = costPerDrink;
        
    }
    
      public int getNumberInvited() 
      {
          return numberInvited;
      }
      
      public void setNumberInvited(int numberInvited)
      {
           this.numberInvited = numberInvited;
      }
      
     public String getTraditionalDessert()
     {
         return traditionalDessert;
     }
     
       

    public double getCostPerDessert() {
        return costPerDessert;
    }

    public void setCostPerDessert(double costPerDessert) {
        this.costPerDessert = costPerDessert;
    }
       
       public String getTraditionalDrink()
       {
           return traditionalDrink;
       }
       
        public void setTraditionalDrink(String traditionalDrink)
        {
             this.traditionalDrink = traditionalDrink;
        }
        
        public double getCostperDessert() 
        {
            return costPerDessert;
        }
        
         public void setCostperDessert(double costperDessert)
         {
             this.costPerDessert =  costperDessert;
         }
         
          public double getCostPerDrink()
          {
              return costPerDrink;
          }
          
           
    public void setCostPerDrink(double costPerDrink)
    {
        this.costPerDrink = costPerDrink;
    }
    
    @Override
    public String celebrate() 
    {
        return "\n" + honor() + "\nWe like the parents to celebrate the holidays like"
                 + toString();
        
    }
    
    public String tabulateCost()
    {
        return super.tabulateCost() + "plus the costs of desserts & drinks per guest: ____" +
                (costPerDessert + costPerDrink) * getNumberInvited();
    }
    
    @Override
    public String toString()
    {
        return super.toString() + "We also like to invite at least"
                + numberInvited + "friends over to our house after our meal to eat"
                + traditionalDessert + "for dessert, and drink" +
                traditionalDrink + "We pay" + costPerDessert + "for each dessert and"
                + costPerDrink + "for each drink";
    }
}


//1. Define 5 additional private attributes that the parents have (don't re-define from the superclass)
//2. Define the Parent constructor that receives 13 parameters,  and invokes the Grandparents constructor first,
//3.  and then initializes the rest of the values in the Parents' attributes.
//4. Define a getter and a setter for each of the 5 attributes in the Parent class
//5. Define the toString() method invoking the 
//   toString() of the super class PLUS it 
//     concatenates its own toString logic:
//
//  We ALSO like to invite at least __ friends over to our house after our meal to eat _____ for dessert, and drink _____.
//  We pay ____ for each dessert, and ____ for each drink. 
//  
//
//6. Define the POLYMORPHIC celebrate method that concatenates "We parents like to celebrate the holidays like " to the toString
//7. Define the POLYMORPHIC tabulateCosts method that concatenates "plus the costs of desserts & drinks per guest: ____"


     
   
