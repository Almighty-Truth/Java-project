/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
Name: Khalil Tobias 
Date: 2/2/2023
Panther ID: 6204983
*/
package holidaycelebrations;

//Code the ChildrensTradition  class here:
public class ChildrenTradition extends ParentsTradition
{
   private String holidayGame;
    private String holidayStorybook;
    private String holidayMovie;
    private double costOfMovie;
    
   
    public ChildrenTradition(String holidayName, String holidaySeason, 
            String timeOfDayCelebration, String mainDishName, int numberOfSideDishes, 
            String locationOfGathering, double costOfMeal, String mealSource, 
            int numberInvited, String traditionalDessert, String traditionalDrink,
            double costPerDessert, double costPerDrink, String holidayGame, 
            String holidayStorybook, String holidayMovie, double costOfMovie) {
        super( holidayName,  holidaySeason, timeOfDayCelebration, 
                mainDishName, numberOfSideDishes, locationOfGathering,  
                costOfMeal, mealSource, numberInvited,  traditionalDessert,  traditionalDrink, 
             costPerDessert,  costPerDrink);
        this.holidayGame = holidayGame;
        this.holidayStorybook = holidayStorybook;
        this.holidayMovie = holidayMovie;
        this.costOfMovie = costOfMovie;
    }
    
   
 
      public String getHolidayGame()
      {
           return holidayGame;
      }
      
      public void setHolidayGame(String holidayGame)
      {
          this.holidayGame = holidayGame;
      }
      
      public String getHolidayStorybook()
      {
          return holidayStorybook;
      }
      
      public void setHolidayStorybook(String holidayStorybook)
      {
          this.holidayStorybook = holidayStorybook;
      }
      
      public String getHolidayMovie()
      {
          return holidayMovie;
      }
      
      public void setHolidayMovie(String holidayMovie)
      {
           this.holidayMovie = holidayMovie;
      }
      
      public double getCostOfMovie()
      {
          return costOfMovie;
      }
      
       public void setCostOfMovie(float costOfMovie) 
       {
            this.costOfMovie = costOfMovie;
       }
    @Override
    public String toString()
    {
        return super.toString() + "We also like to play" + holidayGame + ", read"
                + holidayStorybook + ", and watch holiday movie" + holidayMovie
                + "as a family. The cost of the movie is" + costOfMovie + ".";
    }
    
      @Override
    public String celebrate()
    {
         return "We children like to celebrate the holidays like" + toString();
    }
    
    @Override
    public String tabulateCost()
    {
        return super.tabulateCost() + " plus the cost of the movie: " + costOfMovie;
    }
}
//1. Define 4 additional private attributes that the parents have (don't re-define from the superclass)
//2. Define the Childrens constructor that receives 17 parameters,  and invokes the Parents constructor first,
//3.  and then initializes the rest of the values in the Childrens' attributes.
//4. Define a getter and a setter for each of the 4 attributes in the Children class
//5. Define the toString() method  invoking 
//   the toString() of the super class PLUS it 
//     concatenates its own toString logic:
//
//  AND, before and after our meal we like to play _____.
//  We also like watching holiday movies like _______ which usually cost about _____
//  At bedtime, we like to read holiday stories like _________. 

//  
//
//6. Define the POLYMORPHIC celebrate method that concatenates "We children like to celebrate the holidays like " to the toString
//7. Define the POLYMORPHIC tabulateCosts method that concatenates "plus the cost of a movie: ____"


    

